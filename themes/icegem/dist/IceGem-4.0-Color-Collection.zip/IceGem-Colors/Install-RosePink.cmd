@echo off
call "%~dp0RosePink\Install.cmd" %*
exit /b %ERRORLEVEL%
