@echo off
call "%~dp0IceBlue\Install.cmd" %*
exit /b %ERRORLEVEL%
