@echo off
call "%~dp0Violet\Install.cmd" %*
exit /b %ERRORLEVEL%
