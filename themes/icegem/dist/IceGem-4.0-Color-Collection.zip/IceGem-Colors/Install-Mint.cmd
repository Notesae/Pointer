@echo off
call "%~dp0Mint\Install.cmd" %*
exit /b %ERRORLEVEL%
