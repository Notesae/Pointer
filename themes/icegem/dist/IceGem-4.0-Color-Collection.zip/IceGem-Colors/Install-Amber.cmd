@echo off
call "%~dp0Amber\Install.cmd" %*
exit /b %ERRORLEVEL%
