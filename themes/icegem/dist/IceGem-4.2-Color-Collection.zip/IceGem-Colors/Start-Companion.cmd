@echo off
call "%~dp0companion\Start.cmd"
