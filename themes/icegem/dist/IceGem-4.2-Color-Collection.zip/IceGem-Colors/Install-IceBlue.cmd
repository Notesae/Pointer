@echo off
pushd "%~dp0IceBlue"
call Install.cmd %*
popd
