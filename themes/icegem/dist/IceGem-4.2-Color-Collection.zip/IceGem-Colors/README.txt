IceGem 4.2
Install: Install-<Color>.cmd
Optional interaction: Start-Companion.cmd
Companion does not change the cursor theme or start automatically at login.
