@echo off
pushd "%~dp0RosePink"
call Install.cmd %*
popd
