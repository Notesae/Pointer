@echo off
pushd "%~dp0Mint"
call Install.cmd %*
popd
