@echo off
pushd "%~dp0Violet"
call Install.cmd %*
popd
