@echo off
pushd "%~dp0Amber"
call Install.cmd %*
popd
